"use client";

import { useActionState } from "react";
import { useFormStatus } from "react-dom";
import { adminLogin, studentLogin, submitEnquiry, type FormState } from "@/app/actions";

const initial: FormState = {};

export function SubmitButton({ children, className = "btn btn-navy w-full" }: { children: React.ReactNode; className?: string }) {
  const { pending } = useFormStatus();
  return (
    <button type="submit" disabled={pending} className={className}>
      {pending ? (
        <>
          <span className="h-4 w-4 animate-spin rounded-full border-2 border-current border-t-transparent" />
          Please wait…
        </>
      ) : (
        children
      )}
    </button>
  );
}

function Message({ state }: { state: FormState }) {
  if (state.error)
    return <p className="animate-pop rounded-lg border border-red-200 bg-red-50 px-3 py-2 text-sm text-red-700">{state.error}</p>;
  if (state.success)
    return <p className="animate-pop rounded-lg border border-emerald-200 bg-emerald-50 px-3 py-2 text-sm text-emerald-700">{state.success}</p>;
  return null;
}

export function StudentLoginForm() {
  const [state, action] = useActionState(studentLogin, initial);
  return (
    <form action={action} className="space-y-4">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Roll Number</label>
        <input name="roll" className="input" placeholder="e.g. FA-1001" autoComplete="username" required />
      </div>
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Password</label>
        <input name="password" type="password" className="input" placeholder="••••••••" autoComplete="current-password" required />
      </div>
      <Message state={state} />
      <SubmitButton>Sign in to Portal</SubmitButton>
    </form>
  );
}

export function AdminLoginForm() {
  const [state, action] = useActionState(adminLogin, initial);
  return (
    <form action={action} className="space-y-4">
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Admin Password</label>
        <input name="password" type="password" className="input" placeholder="••••••••" required />
      </div>
      <Message state={state} />
      <SubmitButton>Enter Admin Panel</SubmitButton>
    </form>
  );
}

export function EnquiryForm() {
  const [state, action] = useActionState(submitEnquiry, initial);
  return (
    <form action={action} className="space-y-4">
      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Student Name</label>
          <input name="name" className="input" placeholder="Full name" required />
        </div>
        <div>
          <label className="mb-1.5 block text-sm font-medium text-slate-700">Phone / WhatsApp</label>
          <input name="phone" className="input" placeholder="03XX-XXXXXXX" required />
        </div>
      </div>
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Class</label>
        <select name="className" className="input" defaultValue="9">
          <option value="9">9th Class – Rs. 10,000</option>
          <option value="10">10th Class – Rs. 10,000</option>
          <option value="11">11th Class – Rs. 12,000</option>
          <option value="12">12th Class – Rs. 12,000</option>
        </select>
      </div>
      <div>
        <label className="mb-1.5 block text-sm font-medium text-slate-700">Message (optional)</label>
        <textarea name="message" rows={3} className="input" placeholder="Anything you'd like to ask…" />
      </div>
      <Message state={state} />
      <SubmitButton className="btn btn-gold w-full">Send Admission Enquiry</SubmitButton>
    </form>
  );
}
