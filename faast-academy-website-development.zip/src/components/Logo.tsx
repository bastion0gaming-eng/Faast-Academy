import Link from "next/link";

export default function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-3">
      <span className="relative grid h-10 w-10 place-items-center rounded-xl bg-gradient-to-br from-gold-400 to-gold-600 font-display text-xl font-bold text-navy-900 shadow-lg shadow-gold-500/30 transition-transform duration-500 group-hover:rotate-6 group-hover:scale-105">
        F
      </span>
      <span className="leading-tight">
        <span className={`block font-display text-lg font-bold tracking-wide ${light ? "text-white" : "text-navy-900"}`}>
          FAAST ACADEMY
        </span>
        <span className={`block text-[10px] font-semibold uppercase tracking-[0.2em] ${light ? "text-gold-300" : "text-gold-600"}`}>
          Evening Coaching
        </span>
      </span>
    </Link>
  );
}
