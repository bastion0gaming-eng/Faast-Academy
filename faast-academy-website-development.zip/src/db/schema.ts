import {
  date,
  integer,
  pgTable,
  serial,
  text,
  timestamp,
  unique,
} from "drizzle-orm/pg-core";

export const students = pgTable("students", {
  id: serial("id").primaryKey(),
  rollNo: text("roll_no").notNull().unique(),
  name: text("name").notNull(),
  fatherName: text("father_name").notNull(),
  className: integer("class_name").notNull(),
  grp: text("grp").notNull(),
  phone: text("phone"),
  passwordHash: text("password_hash").notNull(),
  monthlyFee: integer("monthly_fee").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const exams = pgTable("exams", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  className: integer("class_name").notNull(),
  examDate: date("exam_date", { mode: "string" }).notNull(),
  totalMarks: integer("total_marks").notNull(),
});

export const marks = pgTable(
  "marks",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    examId: integer("exam_id")
      .notNull()
      .references(() => exams.id, { onDelete: "cascade" }),
    subject: text("subject").notNull(),
    obtained: integer("obtained").notNull(),
  },
  (t) => [unique().on(t.studentId, t.examId, t.subject)],
);

export const attendance = pgTable(
  "attendance",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    date: date("date", { mode: "string" }).notNull(),
    status: text("status").notNull(), // present | absent | leave
  },
  (t) => [unique().on(t.studentId, t.date)],
);

export const fees = pgTable(
  "fees",
  {
    id: serial("id").primaryKey(),
    studentId: integer("student_id")
      .notNull()
      .references(() => students.id, { onDelete: "cascade" }),
    month: text("month").notNull(), // YYYY-MM
    amount: integer("amount").notNull(),
    paid: integer("paid").notNull().default(0),
    dueDate: date("due_date", { mode: "string" }).notNull(),
    paidOn: timestamp("paid_on"),
  },
  (t) => [unique().on(t.studentId, t.month)],
);

export const announcements = pgTable("announcements", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  body: text("body").notNull(),
  className: integer("class_name"), // null = everyone
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const enquiries = pgTable("enquiries", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  phone: text("phone").notNull(),
  className: integer("class_name"),
  message: text("message"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Student = typeof students.$inferSelect;
