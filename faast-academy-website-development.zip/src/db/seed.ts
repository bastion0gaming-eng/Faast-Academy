import { count } from "drizzle-orm";
import { db } from "@/db";
import { announcements, attendance, exams, fees, marks, students } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { CLASS_FEES, subjectsFor } from "@/lib/constants";

let seeding: Promise<void> | null = null;

export function ensureSeed() {
  if (!seeding) {
    seeding = run().catch((e) => {
      seeding = null;
      throw e;
    });
  }
  return seeding;
}

const iso = (d: Date) => d.toISOString().slice(0, 10);
const daysAgo = (n: number) => {
  const d = new Date();
  d.setUTCDate(d.getUTCDate() - n);
  return d;
};

function rng(seed: number) {
  let s = seed;
  return () => {
    s = (s * 1664525 + 1013904223) % 4294967296;
    return s / 4294967296;
  };
}

async function run() {
  const [{ c }] = await db.select({ c: count() }).from(students);
  if (c > 0) return;

  const pw = hashPassword("faast123");
  const roster = [
    ["FA-901", "Ayesha Khan", "Imran Khan", 9, "Science"],
    ["FA-902", "Hamza Ali", "Shafqat Ali", 9, "Science"],
    ["FA-1001", "Fatima Noor", "Noor Muhammad", 10, "Science"],
    ["FA-1002", "Usman Raza", "Raza Hussain", 10, "Science"],
    ["FA-1101", "Zainab Malik", "Tariq Malik", 11, "Pre-Medical"],
    ["FA-1102", "Bilal Ahmed", "Ahmed Yar", 11, "Pre-Engineering"],
    ["FA-1201", "Hassan Tariq", "Tariq Mehmood", 12, "Pre-Engineering"],
    ["FA-1202", "Maryam Sheikh", "Sheikh Naeem", 12, "Pre-Medical"],
  ] as const;

  const inserted = await db
    .insert(students)
    .values(
      roster.map(([rollNo, name, fatherName, className, grp], i) => ({
        rollNo,
        name,
        fatherName,
        className,
        grp,
        phone: `0300-12345${String(10 + i)}`,
        passwordHash: pw,
        monthlyFee: CLASS_FEES[className],
      })),
    )
    .returning();

  // Exams (per class)
  const examSpecs = [
    { title: "Monthly Test 1", ago: 70, total: 50 },
    { title: "Monthly Test 2", ago: 40, total: 50 },
    { title: "Mid-Term Exam", ago: 12, total: 100 },
  ];
  const examRows: (typeof exams.$inferSelect)[] = [];
  for (const cls of [9, 10, 11, 12]) {
    const rows = await db
      .insert(exams)
      .values(examSpecs.map((e) => ({ title: e.title, className: cls, examDate: iso(daysAgo(e.ago)), totalMarks: e.total })))
      .returning();
    examRows.push(...rows);
  }

  // Marks
  const markRows: (typeof marks.$inferInsert)[] = [];
  inserted.forEach((s, idx) => {
    const r = rng(idx * 97 + 13);
    const base = 58 + r() * 30;
    for (const ex of examRows.filter((e) => e.className === s.className)) {
      for (const subject of subjectsFor(s.className, s.grp)) {
        const pct = Math.max(25, Math.min(98, base + (r() - 0.5) * 26));
        markRows.push({ studentId: s.id, examId: ex.id, subject, obtained: Math.round((pct / 100) * ex.totalMarks) });
      }
    }
  });
  await db.insert(marks).values(markRows);

  // Attendance (last 42 days, Mon–Sat)
  const attRows: (typeof attendance.$inferInsert)[] = [];
  inserted.forEach((s, idx) => {
    const r = rng(idx * 31 + 7);
    for (let n = 1; n <= 42; n++) {
      const d = daysAgo(n);
      if (d.getUTCDay() === 0) continue;
      const x = r();
      const status = x < 0.06 + (idx % 3) * 0.03 ? "absent" : x < 0.12 + (idx % 3) * 0.03 ? "leave" : "present";
      attRows.push({ studentId: s.id, date: iso(d), status });
    }
  });
  await db.insert(attendance).values(attRows);

  // Fees (last 3 months)
  const now = new Date();
  const months = [2, 1, 0].map((k) => {
    const d = new Date(Date.UTC(now.getUTCFullYear(), now.getUTCMonth() - k, 1));
    return { key: d.toISOString().slice(0, 7), k };
  });
  const feeRows: (typeof fees.$inferInsert)[] = [];
  inserted.forEach((s, idx) => {
    for (const { key, k } of months) {
      let paid = 0;
      if (k === 2) paid = s.monthlyFee;
      else if (k === 1) paid = idx % 3 === 0 ? 0 : idx % 4 === 1 ? Math.round(s.monthlyFee / 2) : s.monthlyFee;
      else paid = idx % 2 === 0 ? s.monthlyFee : 0;
      feeRows.push({
        studentId: s.id,
        month: key,
        amount: s.monthlyFee,
        paid,
        dueDate: `${key}-10`,
        paidOn: paid > 0 ? new Date(`${key}-0${3 + (idx % 5)}T10:00:00Z`) : null,
      });
    }
  });
  await db.insert(fees).values(feeRows);

  await db.insert(announcements).values([
    {
      title: "Welcome to FAAST ACADEMY Student Portal",
      body: "You can now check your marks, percentages, attendance and fee dues anytime from this portal.",
      className: null,
    },
    {
      title: "Fee submission reminder",
      body: "Monthly fee must be submitted by the 10th of every month at the academy office, Kohinoor Ali Tower.",
      className: null,
    },
    {
      title: "Chemistry numericals session",
      body: "An extra numericals practice session for Classes 10 & 11 will be held this Saturday evening.",
      className: 10,
    },
    {
      title: "Mid-term results declared",
      body: "Mid-term results for Classes 11 and 12 are now available under the Marks tab.",
      className: 11,
    },
  ]);
}
