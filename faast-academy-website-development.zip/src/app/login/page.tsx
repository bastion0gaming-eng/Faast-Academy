import Link from "next/link";
import { redirect } from "next/navigation";
import Logo from "@/components/Logo";
import { StudentLoginForm } from "@/components/Forms";
import { ensureSeed } from "@/db/seed";
import { getStudentSession } from "@/lib/auth";

export const dynamic = "force-dynamic";

export default async function LoginPage() {
  await ensureSeed();
  if (await getStudentSession()) redirect("/portal");

  return (
    <main className="relative isolate grid min-h-screen place-items-center overflow-hidden bg-navy-950 px-5 py-12">
      <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,#1f4799_0%,transparent_55%),radial-gradient(ellipse_at_bottom_left,#10285c_0%,transparent_60%)]" />
      <div className="animate-drift absolute -left-20 top-10 -z-10 h-72 w-72 rounded-full bg-gold-500/20 blur-3xl" />
      <div className="w-full max-w-md">
        <div className="animate-fade-up mb-8 flex justify-center">
          <Logo light />
        </div>
        <div className="animate-fade-up delay-100 rounded-3xl bg-white p-8 shadow-2xl">
          <h1 className="font-display text-2xl font-bold text-navy-900">Student Portal</h1>
          <p className="mt-1 text-sm text-slate-500">Sign in to view your marks, attendance and fee status.</p>
          <div className="mt-6">
            <StudentLoginForm />
          </div>
          <div className="mt-6 rounded-xl border border-gold-300 bg-gold-300/20 p-4 text-xs leading-relaxed text-navy-800">
            <p className="font-semibold">Demo account</p>
            <p>
              Roll No: <b>FA-1001</b> · Password: <b>faast123</b>
            </p>
            <p className="mt-1 text-navy-700/70">Other demo rolls: FA-901, FA-1101, FA-1201 (same password).</p>
          </div>
        </div>
        <p className="animate-fade-up delay-200 mt-6 text-center text-sm text-white/60">
          <Link href="/" className="transition-colors hover:text-gold-400">
            ← Back to website
          </Link>
          <span className="mx-3">·</span>
          <Link href="/admin" className="transition-colors hover:text-gold-400">
            Admin login
          </Link>
        </p>
      </div>
    </main>
  );
}
