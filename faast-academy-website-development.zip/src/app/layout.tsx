import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";

export const metadata: Metadata = {
  title: "FAAST ACADEMY | Evening Coaching Faisalabad – Classes 9 to 12",
  description:
    "FAAST ACADEMY is an evening coaching academy at Kohinoor Ali Tower, Faisalabad for Classes 9–12. Student portal for marks, percentages, attendance and fee dues.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body className="bg-slate-50 text-slate-900 antialiased">{children}</body>
    </html>
  );
}
