"use client";

import Link from "next/link";
import { useEffect, useMemo, useState } from "react";
import { studentLogout } from "@/app/actions";
import Logo from "@/components/Logo";
import { dateLabel, grade, money, monthLabel } from "@/lib/constants";

type Props = {
  today: string;
  student: { name: string; rollNo: string; fatherName: string; className: number; grp: string; monthlyFee: number };
  exams: { id: number; title: string; examDate: string; totalMarks: number; results: { subject: string; obtained: number }[] }[];
  attendance: { date: string; status: string }[];
  fees: { id: number; month: string; amount: number; paid: number; dueDate: string; paidOn: string | null }[];
  notices: { id: number; title: string; body: string; className: number | null; createdAt: string }[];
};

const TABS = [
  { id: "overview", label: "Overview", icon: "🏠" },
  { id: "marks", label: "Marks", icon: "📝" },
  { id: "attendance", label: "Attendance", icon: "📅" },
  { id: "fees", label: "Fees", icon: "💳" },
  { id: "notices", label: "Notices", icon: "📢" },
] as const;
type TabId = (typeof TABS)[number]["id"];

const pctColor = (p: number) => (p >= 75 ? "text-emerald-600" : p >= 50 ? "text-amber-600" : "text-red-600");
const barColor = (p: number) =>
  p >= 75 ? "from-emerald-500 to-emerald-400" : p >= 50 ? "from-amber-500 to-amber-400" : "from-red-500 to-red-400";

function useMounted() {
  const [m, setM] = useState(false);
  useEffect(() => {
    const t = requestAnimationFrame(() => setM(true));
    return () => cancelAnimationFrame(t);
  }, []);
  return m;
}

function Ring({ value, label, color, size = 120 }: { value: number; label: string; color: string; size?: number }) {
  const mounted = useMounted();
  const r = 48;
  const c = 2 * Math.PI * r;
  const offset = c - ((mounted ? Math.min(100, value) : 0) / 100) * c;
  return (
    <div className="relative grid place-items-center" style={{ width: size, height: size }}>
      <svg viewBox="0 0 120 120" className="-rotate-90" width={size} height={size}>
        <circle cx="60" cy="60" r={r} fill="none" stroke="#e2e8f0" strokeWidth="10" />
        <circle
          cx="60"
          cy="60"
          r={r}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          style={{ transition: "stroke-dashoffset 1.4s cubic-bezier(0.22,1,0.36,1)" }}
        />
      </svg>
      <div className="absolute text-center">
        <p className="font-display text-2xl font-bold text-navy-900">{value.toFixed(0)}%</p>
        <p className="text-[10px] font-medium uppercase tracking-wider text-slate-500">{label}</p>
      </div>
    </div>
  );
}

function Bar({ value, delay = 0 }: { value: number; delay?: number }) {
  const mounted = useMounted();
  return (
    <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
      <div
        className={`bar-fill h-full rounded-full bg-gradient-to-r ${barColor(value)}`}
        style={{ width: `${mounted ? value : 0}%`, transitionDelay: `${delay}ms` }}
      />
    </div>
  );
}

function feeStatus(f: Props["fees"][number], today: string) {
  if (f.paid >= f.amount) return { label: "Paid", cls: "bg-emerald-100 text-emerald-700" };
  if (f.dueDate < today) return { label: f.paid > 0 ? "Partial · Overdue" : "Overdue", cls: "bg-red-100 text-red-700" };
  return { label: f.paid > 0 ? "Partial" : "Pending", cls: "bg-amber-100 text-amber-700" };
}

export default function PortalView({ student, exams, attendance, fees, notices, today }: Props) {
  const [tab, setTab] = useState<TabId>("overview");
  const [examId, setExamId] = useState<number | null>(exams.length ? exams[exams.length - 1].id : null);

  const stats = useMemo(() => {
    const examPct = exams.map((e) => {
      const obtained = e.results.reduce((a, r) => a + r.obtained, 0);
      const total = e.results.length * e.totalMarks;
      return { id: e.id, title: e.title, obtained, total, pct: total ? (obtained / total) * 100 : 0 };
    });
    const tObt = examPct.reduce((a, e) => a + e.obtained, 0);
    const tTot = examPct.reduce((a, e) => a + e.total, 0);
    const present = attendance.filter((a) => a.status === "present").length;
    const absent = attendance.filter((a) => a.status === "absent").length;
    const leave = attendance.filter((a) => a.status === "leave").length;
    const attPct = attendance.length ? (present / attendance.length) * 100 : 0;
    const totalFee = fees.reduce((a, f) => a + f.amount, 0);
    const totalPaid = fees.reduce((a, f) => a + f.paid, 0);
    const due = totalFee - totalPaid;
    const overdue = fees.filter((f) => f.paid < f.amount && f.dueDate < today).reduce((a, f) => a + (f.amount - f.paid), 0);
    return { examPct, overall: tTot ? (tObt / tTot) * 100 : 0, present, absent, leave, attPct, totalFee, totalPaid, due, overdue };
  }, [exams, attendance, fees, today]);

  const selected = exams.find((e) => e.id === examId) ?? null;
  const selectedStats = stats.examPct.find((e) => e.id === examId);
  const latest = exams.length ? exams[exams.length - 1] : null;

  return (
    <div className="min-h-screen bg-slate-100">
      {/* Top bar */}
      <header className="sticky top-0 z-40 bg-navy-950 shadow-lg shadow-navy-950/20">
        <div className="mx-auto flex max-w-6xl items-center justify-between px-5 py-3">
          <Logo light />
          <div className="flex items-center gap-4">
            <div className="hidden text-right sm:block">
              <p className="text-sm font-semibold text-white">{student.name}</p>
              <p className="text-xs text-white/60">{student.rollNo}</p>
            </div>
            <form action={studentLogout}>
              <button className="btn btn-ghost !px-4 !py-2 !text-sm">Sign out</button>
            </form>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-6xl px-5 py-8">
        {/* Profile banner */}
        <section className="animate-fade-up relative overflow-hidden rounded-3xl bg-gradient-to-br from-navy-800 to-navy-600 p-7 text-white shadow-xl sm:p-9">
          <div className="animate-drift absolute -right-10 -top-10 h-56 w-56 rounded-full bg-gold-400/20 blur-3xl" />
          <div className="relative flex flex-wrap items-center justify-between gap-6">
            <div>
              <p className="text-sm text-white/70">Welcome back,</p>
              <h1 className="font-display text-3xl font-bold sm:text-4xl">{student.name}</h1>
              <p className="mt-2 text-sm text-white/70">
                S/O {student.fatherName} · Class {student.className} · {student.grp}
              </p>
            </div>
            <div className="flex gap-3">
              <div className="rounded-2xl bg-white/10 px-5 py-3 text-center backdrop-blur">
                <p className="text-[11px] uppercase tracking-wider text-white/60">Roll No</p>
                <p className="font-display text-lg font-bold text-gold-300">{student.rollNo}</p>
              </div>
              <div className="rounded-2xl bg-white/10 px-5 py-3 text-center backdrop-blur">
                <p className="text-[11px] uppercase tracking-wider text-white/60">Monthly Fee</p>
                <p className="font-display text-lg font-bold text-gold-300">{money(student.monthlyFee)}</p>
              </div>
            </div>
          </div>
        </section>

        {stats.due > 0 && (
          <button
            onClick={() => setTab("fees")}
            className="animate-fade-up delay-100 mt-5 flex w-full items-center gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-5 py-3.5 text-left text-sm text-amber-800 transition-colors hover:bg-amber-100"
          >
            <span className="text-lg">⚠️</span>
            <span className="flex-1">
              You have <b>{money(stats.due)}</b> pending fee{stats.overdue > 0 ? ` (${money(stats.overdue)} overdue)` : ""}. Tap to view details.
            </span>
            <span>→</span>
          </button>
        )}

        {/* Tabs */}
        <nav className="animate-fade-up delay-200 mt-6 flex gap-1 overflow-x-auto rounded-2xl bg-white p-1.5 shadow-sm">
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              className={`flex flex-1 items-center justify-center gap-2 whitespace-nowrap rounded-xl px-4 py-2.5 text-sm font-semibold transition-all duration-300 ${
                tab === t.id ? "bg-navy-800 text-white shadow-md" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              <span>{t.icon}</span>
              {t.label}
            </button>
          ))}
        </nav>

        <div key={tab} className="tab-pane mt-6">
          {/* OVERVIEW */}
          {tab === "overview" && (
            <div className="space-y-6">
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
                <div className="card-lift flex items-center justify-center rounded-2xl bg-white p-5 shadow-sm">
                  <Ring value={stats.overall} label="Overall" color="#2d5bb8" />
                </div>
                <div className="card-lift flex items-center justify-center rounded-2xl bg-white p-5 shadow-sm">
                  <Ring value={stats.attPct} label="Attendance" color="#10b981" />
                </div>
                <div className="card-lift rounded-2xl bg-white p-5 shadow-sm">
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Fee Due</p>
                  <p className={`mt-3 font-display text-3xl font-bold ${stats.due > 0 ? "text-red-600" : "text-emerald-600"}`}>
                    {money(stats.due)}
                  </p>
                  <p className="mt-1 text-xs text-slate-500">
                    {stats.due > 0 ? `${money(stats.totalPaid)} paid so far` : "All dues cleared 🎉"}
                  </p>
                </div>
                <div className="card-lift rounded-2xl bg-white p-5 shadow-sm">
                  <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">Overall Grade</p>
                  <p className="mt-3 font-display text-3xl font-bold text-navy-800">{exams.length ? grade(stats.overall) : "–"}</p>
                  <p className="mt-1 text-xs text-slate-500">{exams.length} exam{exams.length === 1 ? "" : "s"} recorded</p>
                </div>
              </div>

              <div className="grid gap-6 lg:grid-cols-[1.4fr_1fr]">
                <div className="rounded-2xl bg-white p-6 shadow-sm">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-bold text-navy-900">Latest Result</h2>
                    {latest && <span className="text-xs text-slate-500">{latest.title} · {dateLabel(latest.examDate)}</span>}
                  </div>
                  {latest ? (
                    <div className="mt-5 space-y-4">
                      {latest.results.map((r, i) => {
                        const p = (r.obtained / latest.totalMarks) * 100;
                        return (
                          <div key={r.subject}>
                            <div className="mb-1.5 flex justify-between text-sm">
                              <span className="font-medium text-slate-700">{r.subject}</span>
                              <span className="text-slate-500">
                                {r.obtained}/{latest.totalMarks} · <b className={pctColor(p)}>{p.toFixed(0)}%</b>
                              </span>
                            </div>
                            <Bar value={p} delay={i * 80} />
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="mt-4 text-sm text-slate-500">No results yet.</p>
                  )}
                </div>
                <div className="rounded-2xl bg-white p-6 shadow-sm">
                  <div className="flex items-center justify-between">
                    <h2 className="font-display text-lg font-bold text-navy-900">Latest Notices</h2>
                    <button onClick={() => setTab("notices")} className="text-xs font-semibold text-navy-600 hover:underline">
                      View all
                    </button>
                  </div>
                  <ul className="mt-4 space-y-3">
                    {notices.slice(0, 3).map((n) => (
                      <li key={n.id} className="rounded-xl bg-slate-50 p-3.5">
                        <p className="text-sm font-semibold text-navy-900">{n.title}</p>
                        <p className="mt-0.5 line-clamp-2 text-xs text-slate-600">{n.body}</p>
                      </li>
                    ))}
                    {notices.length === 0 && <p className="text-sm text-slate-500">No notices.</p>}
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* MARKS */}
          {tab === "marks" && (
            <div className="space-y-6">
              {exams.length === 0 ? (
                <p className="rounded-2xl bg-white p-8 text-center text-slate-500 shadow-sm">No marks have been added yet.</p>
              ) : (
                <>
                  <div className="rounded-2xl bg-white p-6 shadow-sm">
                    <h2 className="font-display text-lg font-bold text-navy-900">Performance across exams</h2>
                    <div className="mt-6 flex h-44 items-end gap-4 sm:gap-8">
                      {stats.examPct.map((e) => (
                        <ExamColumn key={e.id} title={e.title} pct={e.pct} active={e.id === examId} onClick={() => setExamId(e.id)} />
                      ))}
                    </div>
                  </div>

                  <div className="rounded-2xl bg-white p-6 shadow-sm">
                    <div className="flex flex-wrap gap-2">
                      {exams.map((e) => (
                        <button
                          key={e.id}
                          onClick={() => setExamId(e.id)}
                          className={`rounded-full px-4 py-1.5 text-sm font-semibold transition-all duration-300 ${
                            e.id === examId ? "bg-navy-800 text-white shadow" : "bg-slate-100 text-slate-600 hover:bg-slate-200"
                          }`}
                        >
                          {e.title}
                        </button>
                      ))}
                    </div>
                    {selected && selectedStats && (
                      <div key={selected.id} className="tab-pane mt-6">
                        <div className="overflow-x-auto">
                          <table className="w-full min-w-[480px] text-left text-sm">
                            <thead>
                              <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                                <th className="py-3">Subject</th>
                                <th className="py-3">Obtained</th>
                                <th className="py-3">Total</th>
                                <th className="py-3">Percentage</th>
                                <th className="py-3">Grade</th>
                              </tr>
                            </thead>
                            <tbody>
                              {selected.results.map((r) => {
                                const p = (r.obtained / selected.totalMarks) * 100;
                                return (
                                  <tr key={r.subject} className="border-b border-slate-100 transition-colors hover:bg-slate-50">
                                    <td className="py-3 font-medium text-slate-800">{r.subject}</td>
                                    <td className="py-3">{r.obtained}</td>
                                    <td className="py-3 text-slate-500">{selected.totalMarks}</td>
                                    <td className={`py-3 font-semibold ${pctColor(p)}`}>{p.toFixed(1)}%</td>
                                    <td className="py-3">
                                      <span className="rounded-md bg-navy-50 px-2 py-0.5 text-xs font-bold text-navy-700">{grade(p)}</span>
                                    </td>
                                  </tr>
                                );
                              })}
                            </tbody>
                            <tfoot>
                              <tr className="bg-navy-50 font-bold text-navy-900">
                                <td className="rounded-l-xl px-3 py-3">Total</td>
                                <td className="py-3">{selectedStats.obtained}</td>
                                <td className="py-3">{selectedStats.total}</td>
                                <td className={`py-3 ${pctColor(selectedStats.pct)}`}>{selectedStats.pct.toFixed(1)}%</td>
                                <td className="rounded-r-xl py-3">{grade(selectedStats.pct)}</td>
                              </tr>
                            </tfoot>
                          </table>
                        </div>
                        <p className="mt-3 text-xs text-slate-500">Held on {dateLabel(selected.examDate)}</p>
                      </div>
                    )}
                  </div>
                </>
              )}
            </div>
          )}

          {/* ATTENDANCE */}
          {tab === "attendance" && (
            <div className="space-y-6">
              <div className="grid gap-6 lg:grid-cols-[auto_1fr]">
                <div className="flex items-center justify-center rounded-2xl bg-white p-8 shadow-sm">
                  <Ring value={stats.attPct} label="Present" color="#10b981" size={170} />
                </div>
                <div className="grid grid-cols-2 gap-4 sm:grid-cols-4">
                  {[
                    ["Total Days", attendance.length, "text-navy-800"],
                    ["Present", stats.present, "text-emerald-600"],
                    ["Absent", stats.absent, "text-red-600"],
                    ["Leave", stats.leave, "text-amber-600"],
                  ].map(([l, v, c]) => (
                    <div key={String(l)} className="card-lift rounded-2xl bg-white p-5 shadow-sm">
                      <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{l}</p>
                      <p className={`mt-3 font-display text-4xl font-bold ${c}`}>{v}</p>
                    </div>
                  ))}
                  <div className="col-span-2 rounded-2xl bg-white p-5 shadow-sm sm:col-span-4">
                    <p className="text-sm text-slate-600">
                      {stats.attPct >= 85
                        ? "Excellent attendance. Keep it up! 🌟"
                        : stats.attPct >= 75
                          ? "Good attendance, but try not to miss more classes."
                          : "Your attendance is low. Please attend classes regularly to improve your results."}
                    </p>
                  </div>
                </div>
              </div>

              <div className="rounded-2xl bg-white p-6 shadow-sm">
                <div className="flex flex-wrap items-center justify-between gap-3">
                  <h2 className="font-display text-lg font-bold text-navy-900">Daily record</h2>
                  <div className="flex gap-4 text-xs text-slate-500">
                    {[
                      ["bg-emerald-500", "Present"],
                      ["bg-red-500", "Absent"],
                      ["bg-amber-400", "Leave"],
                    ].map(([c, l]) => (
                      <span key={l} className="flex items-center gap-1.5">
                        <span className={`h-3 w-3 rounded ${c}`} />
                        {l}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  {attendance.map((a, i) => (
                    <div
                      key={a.date}
                      title={`${dateLabel(a.date)} · ${a.status}`}
                      className={`animate-pop grid h-10 w-10 cursor-default place-items-center rounded-lg text-[11px] font-bold text-white transition-transform duration-200 hover:scale-125 ${
                        a.status === "present" ? "bg-emerald-500" : a.status === "absent" ? "bg-red-500" : "bg-amber-400"
                      }`}
                      style={{ animationDelay: `${Math.min(i * 15, 600)}ms` }}
                    >
                      {a.date.slice(8, 10)}
                    </div>
                  ))}
                  {attendance.length === 0 && <p className="text-sm text-slate-500">No attendance recorded yet.</p>}
                </div>
                {stats.absent > 0 && (
                  <div className="mt-6 border-t border-slate-100 pt-5">
                    <p className="text-sm font-semibold text-slate-700">Absent dates</p>
                    <div className="mt-3 flex flex-wrap gap-2">
                      {attendance
                        .filter((a) => a.status === "absent")
                        .reverse()
                        .map((a) => (
                          <span key={a.date} className="rounded-full bg-red-50 px-3 py-1 text-xs font-medium text-red-700">
                            {dateLabel(a.date)}
                          </span>
                        ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* FEES */}
          {tab === "fees" && (
            <div className="space-y-6">
              <div className="grid gap-4 sm:grid-cols-3">
                {[
                  ["Total Billed", money(stats.totalFee), "text-navy-800"],
                  ["Total Paid", money(stats.totalPaid), "text-emerald-600"],
                  ["Balance Due", money(stats.due), stats.due > 0 ? "text-red-600" : "text-emerald-600"],
                ].map(([l, v, c]) => (
                  <div key={l} className="card-lift rounded-2xl bg-white p-6 shadow-sm">
                    <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{l}</p>
                    <p className={`mt-3 font-display text-3xl font-bold ${c}`}>{v}</p>
                  </div>
                ))}
              </div>
              <div className="rounded-2xl bg-white p-6 shadow-sm">
                <h2 className="font-display text-lg font-bold text-navy-900">Fee vouchers</h2>
                <div className="mt-4 overflow-x-auto">
                  <table className="w-full min-w-[560px] text-left text-sm">
                    <thead>
                      <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                        <th className="py-3">Month</th>
                        <th className="py-3">Amount</th>
                        <th className="py-3">Paid</th>
                        <th className="py-3">Balance</th>
                        <th className="py-3">Due Date</th>
                        <th className="py-3">Status</th>
                      </tr>
                    </thead>
                    <tbody>
                      {fees.map((f) => {
                        const st = feeStatus(f, today);
                        return (
                          <tr key={f.id} className="border-b border-slate-100 transition-colors hover:bg-slate-50">
                            <td className="py-3.5 font-medium text-slate-800">{monthLabel(f.month)}</td>
                            <td className="py-3.5">{money(f.amount)}</td>
                            <td className="py-3.5 text-emerald-600">{money(f.paid)}</td>
                            <td className="py-3.5 font-semibold">{money(f.amount - f.paid)}</td>
                            <td className="py-3.5 text-slate-500">{dateLabel(f.dueDate)}</td>
                            <td className="py-3.5">
                              <span className={`rounded-full px-3 py-1 text-xs font-semibold ${st.cls}`}>{st.label}</span>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                  {fees.length === 0 && <p className="py-6 text-center text-sm text-slate-500">No fee records yet.</p>}
                </div>
                <p className="mt-4 rounded-xl bg-navy-50 p-4 text-xs leading-relaxed text-navy-700">
                  💡 Fee is to be submitted at the academy office, Kohinoor Ali Tower, Faisalabad, by the 10th of each month. Your
                  balance updates here once the office records your payment.
                </p>
              </div>
            </div>
          )}

          {/* NOTICES */}
          {tab === "notices" && (
            <div className="space-y-4">
              {notices.map((n, i) => (
                <article
                  key={n.id}
                  className="animate-fade-up card-lift rounded-2xl border-l-4 border-gold-400 bg-white p-6 shadow-sm"
                  style={{ animationDelay: `${i * 70}ms` }}
                >
                  <div className="flex flex-wrap items-center justify-between gap-2">
                    <h3 className="font-display text-lg font-bold text-navy-900">{n.title}</h3>
                    <span className="rounded-full bg-navy-50 px-3 py-1 text-xs font-medium text-navy-700">
                      {n.className ? `Class ${n.className}` : "All classes"} · {dateLabel(n.createdAt)}
                    </span>
                  </div>
                  <p className="mt-2 text-sm leading-relaxed text-slate-600">{n.body}</p>
                </article>
              ))}
              {notices.length === 0 && <p className="rounded-2xl bg-white p-8 text-center text-slate-500">No notices right now.</p>}
            </div>
          )}
        </div>

        <p className="mt-10 text-center text-xs text-slate-500">
          FAAST ACADEMY · Kohinoor Ali Tower, Faisalabad ·{" "}
          <Link href="/" className="font-medium text-navy-600 hover:underline">
            Visit website
          </Link>
        </p>
      </div>
    </div>
  );
}

function ExamColumn({ title, pct, active, onClick }: { title: string; pct: number; active: boolean; onClick: () => void }) {
  const mounted = useMounted();
  return (
    <button onClick={onClick} className="group flex h-full flex-1 flex-col items-center justify-end gap-2">
      <span className={`text-sm font-bold ${pctColor(pct)}`}>{pct.toFixed(0)}%</span>
      <div className="flex w-full max-w-[90px] flex-1 items-end">
        <div
          className={`bar-fill w-full rounded-t-xl bg-gradient-to-t transition-opacity ${
            active ? "from-navy-700 to-navy-400" : "from-navy-200 to-navy-100 group-hover:from-navy-300"
          }`}
          style={{ height: `${mounted ? Math.max(pct, 4) : 0}%` }}
        />
      </div>
      <span className="text-center text-[11px] font-medium leading-tight text-slate-600">{title}</span>
    </button>
  );
}
