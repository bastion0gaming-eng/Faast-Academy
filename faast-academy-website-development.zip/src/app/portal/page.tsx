import { and, asc, desc, eq, isNull, or } from "drizzle-orm";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { announcements, attendance, exams, fees, marks } from "@/db/schema";
import { getStudentSession } from "@/lib/auth";
import { todayISO } from "@/lib/constants";
import PortalView from "./PortalView";

export const dynamic = "force-dynamic";
export const metadata = { title: "Student Portal | FAAST ACADEMY" };

export default async function PortalPage() {
  const s = await getStudentSession();
  if (!s) redirect("/login");

  const [examRows, markRows, attRows, feeRows, notices] = await Promise.all([
    db.select().from(exams).where(eq(exams.className, s.className)).orderBy(asc(exams.examDate)),
    db.select().from(marks).where(eq(marks.studentId, s.id)),
    db.select().from(attendance).where(eq(attendance.studentId, s.id)).orderBy(asc(attendance.date)),
    db.select().from(fees).where(eq(fees.studentId, s.id)).orderBy(desc(fees.month)),
    db
      .select()
      .from(announcements)
      .where(or(isNull(announcements.className), and(eq(announcements.className, s.className))))
      .orderBy(desc(announcements.createdAt))
      .limit(20),
  ]);

  const examsWithResults = examRows
    .map((e) => ({
      id: e.id,
      title: e.title,
      examDate: e.examDate,
      totalMarks: e.totalMarks,
      results: markRows.filter((m) => m.examId === e.id).map((m) => ({ subject: m.subject, obtained: m.obtained })),
    }))
    .filter((e) => e.results.length > 0);

  return (
    <PortalView
      today={todayISO()}
      student={{
        name: s.name,
        rollNo: s.rollNo,
        fatherName: s.fatherName,
        className: s.className,
        grp: s.grp,
        monthlyFee: s.monthlyFee,
      }}
      exams={examsWithResults}
      attendance={attRows.map((a) => ({ date: a.date, status: a.status }))}
      fees={feeRows.map((f) => ({
        id: f.id,
        month: f.month,
        amount: f.amount,
        paid: f.paid,
        dueDate: f.dueDate,
        paidOn: f.paidOn ? f.paidOn.toISOString() : null,
      }))}
      notices={notices.map((n) => ({
        id: n.id,
        title: n.title,
        body: n.body,
        className: n.className,
        createdAt: n.createdAt.toISOString(),
      }))}
    />
  );
}
