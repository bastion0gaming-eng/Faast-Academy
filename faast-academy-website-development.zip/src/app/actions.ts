"use server";

import { and, eq, like, sql } from "drizzle-orm";
import { revalidatePath } from "next/cache";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { db } from "@/db";
import { announcements, attendance, enquiries, exams, fees, marks, students } from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import {
  ADMIN_COOKIE,
  ADMIN_PASSWORD,
  STUDENT_COOKIE,
  hashPassword,
  isAdmin,
  sign,
  verifyPassword,
} from "@/lib/auth";
import { CLASS_FEES, currentMonth } from "@/lib/constants";

export type FormState = { error?: string; success?: string };

const str = (fd: FormData, k: string) => String(fd.get(k) ?? "").trim();

async function requireAdmin() {
  if (!(await isAdmin())) throw new Error("Unauthorized");
}

/* ---------- Public ---------- */

export async function studentLogin(_: FormState, fd: FormData): Promise<FormState> {
  await ensureSeed();
  const roll = str(fd, "roll").toUpperCase();
  const password = String(fd.get("password") ?? "");
  if (!roll || !password) return { error: "Please enter your roll number and password." };
  const [s] = await db.select().from(students).where(eq(students.rollNo, roll)).limit(1);
  if (!s || !verifyPassword(password, s.passwordHash)) {
    return { error: "Invalid roll number or password." };
  }
  (await cookies()).set(STUDENT_COOKIE, sign(String(s.id)), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 24 * 7,
  });
  redirect("/portal");
}

export async function studentLogout() {
  (await cookies()).delete(STUDENT_COOKIE);
  redirect("/login");
}

export async function submitEnquiry(_: FormState, fd: FormData): Promise<FormState> {
  const name = str(fd, "name");
  const phone = str(fd, "phone");
  const cls = Number(str(fd, "className"));
  const message = str(fd, "message");
  if (name.length < 2) return { error: "Please enter your name." };
  if (phone.replace(/\D/g, "").length < 10) return { error: "Please enter a valid phone number." };
  await db.insert(enquiries).values({
    name,
    phone,
    className: [9, 10, 11, 12].includes(cls) ? cls : null,
    message: message || null,
  });
  return { success: "Thank you! We have received your enquiry and will contact you soon." };
}

/* ---------- Admin ---------- */

export async function adminLogin(_: FormState, fd: FormData): Promise<FormState> {
  if (String(fd.get("password") ?? "") !== ADMIN_PASSWORD) return { error: "Incorrect admin password." };
  await ensureSeed();
  (await cookies()).set(ADMIN_COOKIE, sign("admin"), {
    httpOnly: true,
    sameSite: "lax",
    path: "/",
    maxAge: 60 * 60 * 12,
  });
  redirect("/admin");
}

export async function adminLogout() {
  (await cookies()).delete(ADMIN_COOKIE);
  redirect("/admin");
}

export async function addStudent(fd: FormData) {
  await requireAdmin();
  const name = str(fd, "name");
  const fatherName = str(fd, "fatherName");
  const className = Number(str(fd, "className"));
  const grp = str(fd, "grp") || "Science";
  const password = str(fd, "password") || "faast123";
  if (!name || !fatherName || !CLASS_FEES[className]) return;

  const existing = await db
    .select({ r: students.rollNo })
    .from(students)
    .where(like(students.rollNo, `FA-${className}%`));
  let n = existing.length + 1;
  const taken = new Set(existing.map((e) => e.r));
  let rollNo = `FA-${className}${String(n).padStart(2, "0")}`;
  while (taken.has(rollNo)) rollNo = `FA-${className}${String(++n).padStart(2, "0")}`;

  const [s] = await db
    .insert(students)
    .values({
      rollNo,
      name,
      fatherName,
      className,
      grp,
      phone: str(fd, "phone") || null,
      passwordHash: hashPassword(password),
      monthlyFee: CLASS_FEES[className],
    })
    .returning();
  const month = currentMonth();
  await db
    .insert(fees)
    .values({ studentId: s.id, month, amount: s.monthlyFee, dueDate: `${month}-10` })
    .onConflictDoNothing();
  revalidatePath("/admin");
}

export async function deleteStudent(fd: FormData) {
  await requireAdmin();
  await db.delete(students).where(eq(students.id, Number(fd.get("id"))));
  revalidatePath("/admin");
}

export async function createExam(fd: FormData) {
  await requireAdmin();
  const title = str(fd, "title");
  const className = Number(str(fd, "className"));
  const totalMarks = Number(str(fd, "totalMarks"));
  const examDate = str(fd, "examDate");
  if (!title || !CLASS_FEES[className] || !(totalMarks > 0) || !examDate) return;
  const [e] = await db.insert(exams).values({ title, className, totalMarks, examDate }).returning();
  revalidatePath("/admin");
  redirect(`/admin?tab=marks&exam=${e.id}`);
}

export async function saveMarks(fd: FormData) {
  await requireAdmin();
  const examId = Number(fd.get("exam"));
  const [exam] = await db.select().from(exams).where(eq(exams.id, examId)).limit(1);
  if (!exam) return;
  const rows: (typeof marks.$inferInsert)[] = [];
  for (const [key, val] of fd.entries()) {
    if (!key.startsWith("m_")) continue;
    const raw = String(val).trim();
    if (raw === "") continue;
    const [, sid, subject] = key.split("_");
    const n = Math.max(0, Math.min(exam.totalMarks, Math.round(Number(raw))));
    if (Number.isNaN(n)) continue;
    rows.push({ studentId: Number(sid), examId, subject, obtained: n });
  }
  if (rows.length) {
    await db
      .insert(marks)
      .values(rows)
      .onConflictDoUpdate({
        target: [marks.studentId, marks.examId, marks.subject],
        set: { obtained: sql`excluded.obtained` },
      });
  }
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function saveAttendance(fd: FormData) {
  await requireAdmin();
  const date = str(fd, "date");
  if (!date) return;
  const rows: (typeof attendance.$inferInsert)[] = [];
  for (const [key, val] of fd.entries()) {
    if (!key.startsWith("s_")) continue;
    const status = String(val);
    if (!["present", "absent", "leave"].includes(status)) continue;
    rows.push({ studentId: Number(key.slice(2)), date, status });
  }
  if (rows.length) {
    await db
      .insert(attendance)
      .values(rows)
      .onConflictDoUpdate({
        target: [attendance.studentId, attendance.date],
        set: { status: sql`excluded.status` },
      });
  }
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function generateFees(fd: FormData) {
  await requireAdmin();
  const month = str(fd, "month");
  if (!/^\d{4}-\d{2}$/.test(month)) return;
  const all = await db.select().from(students);
  if (all.length) {
    await db
      .insert(fees)
      .values(all.map((s) => ({ studentId: s.id, month, amount: s.monthlyFee, dueDate: `${month}-10` })))
      .onConflictDoNothing();
  }
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function recordPayment(fd: FormData) {
  await requireAdmin();
  const id = Number(fd.get("id"));
  const amount = Math.round(Number(fd.get("amount")));
  if (!(amount > 0)) return;
  const [f] = await db.select().from(fees).where(eq(fees.id, id)).limit(1);
  if (!f) return;
  await db
    .update(fees)
    .set({ paid: Math.min(f.amount, f.paid + amount), paidOn: new Date() })
    .where(and(eq(fees.id, id)));
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function postAnnouncement(fd: FormData) {
  await requireAdmin();
  const title = str(fd, "title");
  const body = str(fd, "body");
  const cls = Number(str(fd, "className"));
  if (!title || !body) return;
  await db.insert(announcements).values({ title, body, className: CLASS_FEES[cls] ? cls : null });
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function deleteAnnouncement(fd: FormData) {
  await requireAdmin();
  await db.delete(announcements).where(eq(announcements.id, Number(fd.get("id"))));
  revalidatePath("/admin");
  revalidatePath("/portal");
}

export async function deleteEnquiry(fd: FormData) {
  await requireAdmin();
  await db.delete(enquiries).where(eq(enquiries.id, Number(fd.get("id"))));
  revalidatePath("/admin");
}
