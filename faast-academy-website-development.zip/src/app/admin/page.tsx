import Link from "next/link";
import { asc, count, desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { announcements, attendance, enquiries, exams, fees, marks, students } from "@/db/schema";
import { ensureSeed } from "@/db/seed";
import {
  addStudent,
  adminLogout,
  createExam,
  deleteAnnouncement,
  deleteEnquiry,
  deleteStudent,
  generateFees,
  postAnnouncement,
  recordPayment,
  saveAttendance,
  saveMarks,
} from "@/app/actions";
import Logo from "@/components/Logo";
import { AdminLoginForm, SubmitButton } from "@/components/Forms";
import { isAdmin } from "@/lib/auth";
import { CLASSES, CLASS_FEES, currentMonth, dateLabel, groupsFor, money, monthLabel, subjectsFor, todayISO } from "@/lib/constants";

export const dynamic = "force-dynamic";
export const metadata = { title: "Admin | FAAST ACADEMY" };

const TABS = [
  ["overview", "Overview"],
  ["students", "Students"],
  ["marks", "Marks"],
  ["attendance", "Attendance"],
  ["fees", "Fees"],
  ["notices", "Notices"],
  ["enquiries", "Enquiries"],
] as const;

type SP = { tab?: string; exam?: string; cls?: string; date?: string; filter?: string };

function Card({ title, children, className = "" }: { title?: string; children: React.ReactNode; className?: string }) {
  return (
    <section className={`rounded-2xl bg-white p-6 shadow-sm ${className}`}>
      {title && <h2 className="mb-4 font-display text-lg font-bold text-navy-900">{title}</h2>}
      {children}
    </section>
  );
}

const Label = ({ children }: { children: React.ReactNode }) => (
  <label className="mb-1 block text-xs font-semibold uppercase tracking-wider text-slate-500">{children}</label>
);

export default async function AdminPage({ searchParams }: { searchParams: Promise<SP> }) {
  if (!(await isAdmin())) {
    await ensureSeed();
    return (
      <main className="relative isolate grid min-h-screen place-items-center overflow-hidden bg-navy-950 px-5 py-12">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,#1f4799_0%,transparent_55%)]" />
        <div className="w-full max-w-md">
          <div className="animate-fade-up mb-8 flex justify-center">
            <Logo light />
          </div>
          <div className="animate-fade-up delay-100 rounded-3xl bg-white p-8 shadow-2xl">
            <h1 className="font-display text-2xl font-bold text-navy-900">Admin Panel</h1>
            <p className="mt-1 text-sm text-slate-500">Manage students, marks, attendance and fees.</p>
            <div className="mt-6">
              <AdminLoginForm />
            </div>
            <p className="mt-5 rounded-xl bg-gold-300/20 p-3 text-xs text-navy-800">
              Default demo password: <b>faast-admin</b> (set the <code>ADMIN_PASSWORD</code> environment variable to change it).
            </p>
          </div>
          <p className="mt-6 text-center text-sm text-white/60">
            <Link href="/" className="hover:text-gold-400">
              ← Back to website
            </Link>
          </p>
        </div>
      </main>
    );
  }

  const sp = await searchParams;
  const tab = TABS.some(([id]) => id === sp.tab) ? (sp.tab as string) : "overview";

  return (
    <div className="min-h-screen bg-slate-100">
      <header className="sticky top-0 z-40 bg-navy-950 shadow-lg">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-5 py-3">
          <Logo light />
          <div className="flex items-center gap-4">
            <span className="hidden rounded-full bg-gold-400/20 px-3 py-1 text-xs font-semibold text-gold-300 sm:inline">Administrator</span>
            <form action={adminLogout}>
              <button className="btn btn-ghost !px-4 !py-2 !text-sm">Sign out</button>
            </form>
          </div>
        </div>
      </header>

      <div className="mx-auto max-w-7xl px-5 py-8">
        <nav className="mb-6 flex gap-1 overflow-x-auto rounded-2xl bg-white p-1.5 shadow-sm">
          {TABS.map(([id, label]) => (
            <Link
              key={id}
              href={`/admin?tab=${id}`}
              className={`whitespace-nowrap rounded-xl px-5 py-2.5 text-sm font-semibold transition-all duration-300 ${
                tab === id ? "bg-navy-800 text-white shadow-md" : "text-slate-600 hover:bg-slate-100"
              }`}
            >
              {label}
            </Link>
          ))}
        </nav>

        <div key={tab} className="tab-pane">
          {tab === "overview" && <Overview />}
          {tab === "students" && <Students />}
          {tab === "marks" && <Marks sp={sp} />}
          {tab === "attendance" && <Attendance sp={sp} />}
          {tab === "fees" && <Fees sp={sp} />}
          {tab === "notices" && <Notices />}
          {tab === "enquiries" && <Enquiries />}
        </div>
      </div>
    </div>
  );
}

/* ---------------- Overview ---------------- */
async function Overview() {
  const month = currentMonth();
  const [[sc], [ec], feeAgg, [att], byClass] = await Promise.all([
    db.select({ c: count() }).from(students),
    db.select({ c: count() }).from(enquiries),
    db
      .select({
        billed: sql<number>`coalesce(sum(${fees.amount}),0)::int`,
        paid: sql<number>`coalesce(sum(${fees.paid}),0)::int`,
      })
      .from(fees),
    db
      .select({
        total: count(),
        present: sql<number>`count(*) filter (where ${attendance.status} = 'present')::int`,
      })
      .from(attendance),
    db
      .select({ cls: students.className, c: count() })
      .from(students)
      .groupBy(students.className)
      .orderBy(asc(students.className)),
  ]);
  const [mfee] = await db
    .select({
      billed: sql<number>`coalesce(sum(${fees.amount}),0)::int`,
      paid: sql<number>`coalesce(sum(${fees.paid}),0)::int`,
    })
    .from(fees)
    .where(eq(fees.month, month));

  const stats = [
    ["Students", String(sc.c), "text-navy-800"],
    ["Avg. Attendance", att.total ? `${Math.round((att.present / att.total) * 100)}%` : "–", "text-emerald-600"],
    ["Total Outstanding", money(feeAgg[0].billed - feeAgg[0].paid), "text-red-600"],
    ["Open Enquiries", String(ec.c), "text-gold-600"],
  ];

  return (
    <div className="space-y-6">
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {stats.map(([l, v, c]) => (
          <div key={l} className="card-lift rounded-2xl bg-white p-6 shadow-sm">
            <p className="text-xs font-semibold uppercase tracking-wider text-slate-500">{l}</p>
            <p className={`mt-3 font-display text-3xl font-bold ${c}`}>{v}</p>
          </div>
        ))}
      </div>
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Students by class">
          <ul className="space-y-3">
            {CLASSES.map((cls) => {
              const n = byClass.find((b) => b.cls === cls)?.c ?? 0;
              const pct = sc.c ? (n / sc.c) * 100 : 0;
              return (
                <li key={cls}>
                  <div className="mb-1 flex justify-between text-sm">
                    <span className="font-medium text-slate-700">Class {cls}</span>
                    <span className="text-slate-500">
                      {n} · {money(CLASS_FEES[cls])}/mo
                    </span>
                  </div>
                  <div className="h-2.5 overflow-hidden rounded-full bg-slate-100">
                    <div className="h-full rounded-full bg-gradient-to-r from-navy-600 to-navy-400" style={{ width: `${pct}%` }} />
                  </div>
                </li>
              );
            })}
          </ul>
        </Card>
        <Card title={`Fee collection · ${monthLabel(month)}`}>
          <p className="font-display text-3xl font-bold text-navy-800">{money(mfee.paid)}</p>
          <p className="text-sm text-slate-500">collected of {money(mfee.billed)} billed</p>
          <div className="mt-4 h-3 overflow-hidden rounded-full bg-slate-100">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-500 to-emerald-400"
              style={{ width: `${mfee.billed ? (mfee.paid / mfee.billed) * 100 : 0}%` }}
            />
          </div>
          <p className="mt-6 text-sm text-slate-600">
            Use the <b>Fees</b> tab to generate vouchers for a new month and record payments.
          </p>
        </Card>
      </div>
    </div>
  );
}

/* ---------------- Students ---------------- */
async function Students() {
  const list = await db.select().from(students).orderBy(asc(students.className), asc(students.rollNo));
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_340px]">
      <Card title={`All students (${list.length})`}>
        <div className="overflow-x-auto">
          <table className="w-full min-w-[560px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                <th className="py-3">Roll</th>
                <th className="py-3">Name</th>
                <th className="py-3">Class</th>
                <th className="py-3">Group</th>
                <th className="py-3">Fee</th>
                <th className="py-3" />
              </tr>
            </thead>
            <tbody>
              {list.map((s) => (
                <tr key={s.id} className="border-b border-slate-100 hover:bg-slate-50">
                  <td className="py-3 font-mono text-xs font-semibold text-navy-700">{s.rollNo}</td>
                  <td className="py-3">
                    <p className="font-medium text-slate-800">{s.name}</p>
                    <p className="text-xs text-slate-500">S/O {s.fatherName}</p>
                  </td>
                  <td className="py-3">{s.className}th</td>
                  <td className="py-3 text-slate-600">{s.grp}</td>
                  <td className="py-3">{money(s.monthlyFee)}</td>
                  <td className="py-3 text-right">
                    <form action={deleteStudent}>
                      <input type="hidden" name="id" value={s.id} />
                      <button className="text-xs font-semibold text-red-600 hover:underline">Remove</button>
                    </form>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </Card>
      <Card title="Add new student" className="h-fit">
        <form action={addStudent} className="space-y-3">
          <div>
            <Label>Student name</Label>
            <input name="name" className="input" required />
          </div>
          <div>
            <Label>Father name</Label>
            <input name="fatherName" className="input" required />
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div>
              <Label>Class</Label>
              <select name="className" className="input" defaultValue="9">
                {CLASSES.map((c) => (
                  <option key={c} value={c}>
                    {c}th – {money(CLASS_FEES[c])}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <Label>Group</Label>
              <select name="grp" className="input">
                {Array.from(new Set(CLASSES.flatMap((c) => groupsFor(c)))).map((g) => (
                  <option key={g}>{g}</option>
                ))}
              </select>
            </div>
          </div>
          <div>
            <Label>Phone</Label>
            <input name="phone" className="input" />
          </div>
          <div>
            <Label>Portal password</Label>
            <input name="password" className="input" placeholder="default: faast123" />
          </div>
          <p className="text-xs text-slate-500">Roll number is generated automatically. Fee is set from the class.</p>
          <SubmitButton>Add Student</SubmitButton>
        </form>
      </Card>
    </div>
  );
}

/* ---------------- Marks ---------------- */
async function Marks({ sp }: { sp: SP }) {
  const examList = await db.select().from(exams).orderBy(desc(exams.examDate));
  const exam = examList.find((e) => String(e.id) === sp.exam);

  let grid: React.ReactNode = null;
  if (exam) {
    const [studs, existing] = await Promise.all([
      db.select().from(students).where(eq(students.className, exam.className)).orderBy(asc(students.rollNo)),
      db.select().from(marks).where(eq(marks.examId, exam.id)),
    ]);
    const get = (sid: number, sub: string) => existing.find((m) => m.studentId === sid && m.subject === sub)?.obtained;
    grid = (
      <Card title={`${exam.title} · Class ${exam.className} · out of ${exam.totalMarks} per subject`}>
        {studs.length === 0 ? (
          <p className="text-sm text-slate-500">No students in this class yet.</p>
        ) : (
          <form action={saveMarks} className="space-y-6">
            <input type="hidden" name="exam" value={exam.id} />
            {studs.map((s) => (
              <div key={s.id} className="rounded-xl border border-slate-200 p-4">
                <p className="mb-3 text-sm font-semibold text-navy-900">
                  {s.name} <span className="font-mono text-xs text-slate-500">({s.rollNo} · {s.grp})</span>
                </p>
                <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 lg:grid-cols-6">
                  {subjectsFor(s.className, s.grp).map((sub) => (
                    <div key={sub}>
                      <Label>{sub}</Label>
                      <input
                        type="number"
                        min={0}
                        max={exam.totalMarks}
                        name={`m_${s.id}_${sub}`}
                        defaultValue={get(s.id, sub)}
                        className="input !py-2"
                      />
                    </div>
                  ))}
                </div>
              </div>
            ))}
            <SubmitButton className="btn btn-navy">Save Marks</SubmitButton>
          </form>
        )}
      </Card>
    );
  }

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
        <Card title="Select an exam to enter marks">
          <div className="flex flex-wrap gap-2">
            {examList.map((e) => (
              <Link
                key={e.id}
                href={`/admin?tab=marks&exam=${e.id}`}
                className={`rounded-full px-4 py-2 text-sm font-semibold transition-all duration-300 ${
                  exam?.id === e.id ? "bg-navy-800 text-white shadow" : "bg-slate-100 text-slate-700 hover:bg-slate-200"
                }`}
              >
                {e.title} · {e.className}th <span className="opacity-60">({dateLabel(e.examDate)})</span>
              </Link>
            ))}
            {examList.length === 0 && <p className="text-sm text-slate-500">No exams yet. Create one →</p>}
          </div>
        </Card>
        <Card title="Create new exam">
          <form action={createExam} className="space-y-3">
            <div>
              <Label>Title</Label>
              <input name="title" className="input" placeholder="e.g. Monthly Test 3" required />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <Label>Class</Label>
                <select name="className" className="input">
                  {CLASSES.map((c) => (
                    <option key={c} value={c}>
                      {c}th
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <Label>Total marks</Label>
                <input name="totalMarks" type="number" min={1} defaultValue={50} className="input" required />
              </div>
            </div>
            <div>
              <Label>Date</Label>
              <input name="examDate" type="date" defaultValue={todayISO()} className="input" required />
            </div>
            <SubmitButton>Create Exam</SubmitButton>
          </form>
        </Card>
      </div>
      {grid}
    </div>
  );
}

/* ---------------- Attendance ---------------- */
async function Attendance({ sp }: { sp: SP }) {
  const cls = CLASSES.find((c) => String(c) === sp.cls) ?? 9;
  const date = sp.date && /^\d{4}-\d{2}-\d{2}$/.test(sp.date) ? sp.date : todayISO();
  const [studs, existing] = await Promise.all([
    db.select().from(students).where(eq(students.className, cls)).orderBy(asc(students.rollNo)),
    db.select().from(attendance).where(eq(attendance.date, date)),
  ]);
  const opts = [
    ["present", "Present", "has-[:checked]:bg-emerald-500"],
    ["absent", "Absent", "has-[:checked]:bg-red-500"],
    ["leave", "Leave", "has-[:checked]:bg-amber-400"],
  ] as const;

  return (
    <div className="space-y-6">
      <Card>
        <form method="get" className="flex flex-wrap items-end gap-4">
          <input type="hidden" name="tab" value="attendance" />
          <div>
            <Label>Class</Label>
            <select name="cls" defaultValue={cls} className="input">
              {CLASSES.map((c) => (
                <option key={c} value={c}>
                  {c}th
                </option>
              ))}
            </select>
          </div>
          <div>
            <Label>Date</Label>
            <input type="date" name="date" defaultValue={date} className="input" />
          </div>
          <button className="btn btn-outline">Load</button>
        </form>
      </Card>
      <Card title={`Class ${cls} · ${dateLabel(date)}`}>
        {studs.length === 0 ? (
          <p className="text-sm text-slate-500">No students in this class.</p>
        ) : (
          <form action={saveAttendance} className="space-y-3">
            <input type="hidden" name="date" value={date} />
            {studs.map((s) => {
              const cur = existing.find((e) => e.studentId === s.id)?.status ?? "present";
              return (
                <div key={s.id} className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-slate-200 p-3">
                  <div>
                    <p className="text-sm font-semibold text-slate-800">{s.name}</p>
                    <p className="font-mono text-xs text-slate-500">{s.rollNo}</p>
                  </div>
                  <div className="flex gap-2">
                    {opts.map(([v, l, cl]) => (
                      <label
                        key={v}
                        className={`cursor-pointer rounded-lg bg-slate-100 px-4 py-2 text-xs font-semibold text-slate-600 transition-colors has-[:checked]:text-white ${cl}`}
                      >
                        <input type="radio" name={`s_${s.id}`} value={v} defaultChecked={cur === v} className="sr-only" />
                        {l}
                      </label>
                    ))}
                  </div>
                </div>
              );
            })}
            <SubmitButton className="btn btn-navy">Save Attendance</SubmitButton>
          </form>
        )}
      </Card>
    </div>
  );
}

/* ---------------- Fees ---------------- */
async function Fees({ sp }: { sp: SP }) {
  const dueOnly = sp.filter === "due";
  const rows = await db
    .select({
      id: fees.id,
      month: fees.month,
      amount: fees.amount,
      paid: fees.paid,
      dueDate: fees.dueDate,
      name: students.name,
      rollNo: students.rollNo,
      cls: students.className,
    })
    .from(fees)
    .innerJoin(students, eq(fees.studentId, students.id))
    .where(dueOnly ? sql`${fees.paid} < ${fees.amount}` : undefined)
    .orderBy(desc(fees.month), asc(students.rollNo))
    .limit(200);
  const today = todayISO();

  return (
    <div className="space-y-6">
      <div className="grid gap-6 lg:grid-cols-2">
        <Card title="Generate monthly fee vouchers">
          <form action={generateFees} className="flex flex-wrap items-end gap-3">
            <div>
              <Label>Month</Label>
              <input type="month" name="month" defaultValue={currentMonth()} className="input" />
            </div>
            <SubmitButton className="btn btn-navy">Generate for all students</SubmitButton>
          </form>
          <p className="mt-3 text-xs text-slate-500">Existing vouchers are never duplicated. Due date is the 10th.</p>
        </Card>
        <Card title="View">
          <div className="flex gap-2">
            <Link
              href="/admin?tab=fees"
              className={`rounded-full px-4 py-2 text-sm font-semibold ${!dueOnly ? "bg-navy-800 text-white" : "bg-slate-100 text-slate-700"}`}
            >
              All vouchers
            </Link>
            <Link
              href="/admin?tab=fees&filter=due"
              className={`rounded-full px-4 py-2 text-sm font-semibold ${dueOnly ? "bg-navy-800 text-white" : "bg-slate-100 text-slate-700"}`}
            >
              Unpaid / partial only
            </Link>
          </div>
        </Card>
      </div>
      <Card title="Fee vouchers">
        <div className="overflow-x-auto">
          <table className="w-full min-w-[720px] text-left text-sm">
            <thead>
              <tr className="border-b border-slate-200 text-xs uppercase tracking-wider text-slate-500">
                <th className="py-3">Student</th>
                <th className="py-3">Month</th>
                <th className="py-3">Amount</th>
                <th className="py-3">Paid</th>
                <th className="py-3">Balance</th>
                <th className="py-3">Receive payment</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => {
                const bal = r.amount - r.paid;
                return (
                  <tr key={r.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-3">
                      <p className="font-medium text-slate-800">{r.name}</p>
                      <p className="font-mono text-xs text-slate-500">
                        {r.rollNo} · {r.cls}th
                      </p>
                    </td>
                    <td className="py-3">{monthLabel(r.month)}</td>
                    <td className="py-3">{money(r.amount)}</td>
                    <td className="py-3 text-emerald-600">{money(r.paid)}</td>
                    <td className={`py-3 font-semibold ${bal > 0 ? (r.dueDate < today ? "text-red-600" : "text-amber-600") : "text-emerald-600"}`}>
                      {bal > 0 ? money(bal) : "Paid ✓"}
                    </td>
                    <td className="py-3">
                      {bal > 0 && (
                        <form action={recordPayment} className="flex gap-2">
                          <input type="hidden" name="id" value={r.id} />
                          <input name="amount" type="number" min={1} max={bal} defaultValue={bal} className="input !w-28 !py-1.5" />
                          <button className="btn btn-navy !px-3 !py-1.5 !text-xs">Receive</button>
                        </form>
                      )}
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
          {rows.length === 0 && <p className="py-6 text-center text-sm text-slate-500">Nothing to show.</p>}
        </div>
      </Card>
    </div>
  );
}

/* ---------------- Notices ---------------- */
async function Notices() {
  const list = await db.select().from(announcements).orderBy(desc(announcements.createdAt));
  return (
    <div className="grid gap-6 lg:grid-cols-[1fr_360px]">
      <Card title="Posted notices">
        <ul className="space-y-3">
          {list.map((n) => (
            <li key={n.id} className="flex items-start justify-between gap-4 rounded-xl border border-slate-200 p-4">
              <div>
                <p className="font-semibold text-navy-900">{n.title}</p>
                <p className="mt-1 text-sm text-slate-600">{n.body}</p>
                <p className="mt-2 text-xs text-slate-500">
                  {n.className ? `Class ${n.className}` : "All classes"} · {dateLabel(n.createdAt.toISOString())}
                </p>
              </div>
              <form action={deleteAnnouncement}>
                <input type="hidden" name="id" value={n.id} />
                <button className="text-xs font-semibold text-red-600 hover:underline">Delete</button>
              </form>
            </li>
          ))}
          {list.length === 0 && <p className="text-sm text-slate-500">No notices.</p>}
        </ul>
      </Card>
      <Card title="Post a notice" className="h-fit">
        <form action={postAnnouncement} className="space-y-3">
          <div>
            <Label>Title</Label>
            <input name="title" className="input" required />
          </div>
          <div>
            <Label>Message</Label>
            <textarea name="body" rows={4} className="input" required />
          </div>
          <div>
            <Label>Audience</Label>
            <select name="className" className="input">
              <option value="">All classes</option>
              {CLASSES.map((c) => (
                <option key={c} value={c}>
                  Class {c} only
                </option>
              ))}
            </select>
          </div>
          <SubmitButton>Publish Notice</SubmitButton>
        </form>
      </Card>
    </div>
  );
}

/* ---------------- Enquiries ---------------- */
async function Enquiries() {
  const list = await db.select().from(enquiries).orderBy(desc(enquiries.createdAt));
  return (
    <Card title={`Admission enquiries (${list.length})`}>
      <ul className="space-y-3">
        {list.map((e) => (
          <li key={e.id} className="flex items-start justify-between gap-4 rounded-xl border border-slate-200 p-4">
            <div>
              <p className="font-semibold text-navy-900">
                {e.name} <span className="ml-2 text-sm font-normal text-slate-500">{e.phone}</span>
              </p>
              <p className="text-xs text-slate-500">
                {e.className ? `Class ${e.className}` : "Class not specified"} · {dateLabel(e.createdAt.toISOString())}
              </p>
              {e.message && <p className="mt-2 text-sm text-slate-600">{e.message}</p>}
            </div>
            <form action={deleteEnquiry}>
              <input type="hidden" name="id" value={e.id} />
              <button className="text-xs font-semibold text-red-600 hover:underline">Done</button>
            </form>
          </li>
        ))}
        {list.length === 0 && <p className="text-sm text-slate-500">No enquiries yet. Submissions from the website admission form appear here.</p>}
      </ul>
    </Card>
  );
}
