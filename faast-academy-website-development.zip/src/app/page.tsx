import Link from "next/link";
import Navbar from "@/components/Navbar";
import Logo from "@/components/Logo";
import Reveal from "@/components/Reveal";
import { EnquiryForm } from "@/components/Forms";
import { ACADEMY, CLASS_FEES, money } from "@/lib/constants";

const classCards = [
  {
    cls: 9,
    title: "9th Class",
    desc: "A strong foundation in Science, Mathematics and English with concept-first teaching.",
    subjects: ["Physics", "Chemistry", "Biology", "Maths", "English", "Urdu"],
  },
  {
    cls: 10,
    title: "10th Class",
    desc: "Board-focused preparation with weekly tests, past papers and numerical practice.",
    subjects: ["Physics", "Chemistry", "Biology", "Maths", "English", "Urdu"],
    popular: true,
  },
  {
    cls: 11,
    title: "11th Class (FSc 1)",
    desc: "Pre-Medical and Pre-Engineering groups taught by experienced subject specialists.",
    subjects: ["Physics", "Chemistry", "Biology / Maths", "English", "Urdu"],
  },
  {
    cls: 12,
    title: "12th Class (FSc 2)",
    desc: "Complete board and entry-test oriented coaching with full-length mock exams.",
    subjects: ["Physics", "Chemistry", "Biology / Maths", "English", "Urdu"],
  },
];

const portalFeatures = [
  { icon: "📝", title: "Marks & Results", text: "Subject-wise marks for every test and exam, with grades." },
  { icon: "📈", title: "Percentages", text: "Overall and per-exam percentage with progress across tests." },
  { icon: "📅", title: "Attendance", text: "Daily attendance record with present, absent and leave tracking." },
  { icon: "💳", title: "Fee Dues", text: "Monthly vouchers, payments received and pending balance at a glance." },
  { icon: "📢", title: "Notices", text: "Class-wise announcements, test dates and academy updates." },
  { icon: "🔒", title: "Private & Secure", text: "Every student signs in with their own roll number and password." },
];

const why = [
  { n: "01", title: "Experienced Teachers", text: "Subject specialists who explain concepts clearly and keep every student engaged." },
  { n: "02", title: "Regular Testing", text: "Weekly and monthly tests with marks shared with students and parents on the portal." },
  { n: "03", title: "Evening Timings", text: "Evening batches that fit around school and college hours, Monday to Saturday." },
  { n: "04", title: "Parent Transparency", text: "Attendance, results and fee status are always visible, so nothing is a surprise." },
];

export default function Home() {
  return (
    <main className="overflow-x-hidden">
      <Navbar />

      {/* HERO */}
      <section className="relative isolate overflow-hidden bg-navy-950 pb-24 pt-36 text-white lg:pb-32 lg:pt-44">
        <div className="absolute inset-0 -z-10 bg-[radial-gradient(ellipse_at_top_right,#1f4799_0%,transparent_55%),radial-gradient(ellipse_at_bottom_left,#10285c_0%,transparent_60%)]" />
        <div className="animate-drift absolute -left-24 top-24 -z-10 h-80 w-80 rounded-full bg-gold-500/20 blur-3xl" />
        <div className="animate-drift absolute -right-20 bottom-0 -z-10 h-96 w-96 rounded-full bg-navy-500/30 blur-3xl [animation-delay:-6s]" />
        <div className="absolute inset-0 -z-10 opacity-[0.07] [background-image:linear-gradient(white_1px,transparent_1px),linear-gradient(90deg,white_1px,transparent_1px)] [background-size:56px_56px]" />

        <div className="mx-auto grid max-w-7xl items-center gap-14 px-5 lg:grid-cols-2">
          <div>
            <span className="animate-fade-up inline-flex items-center gap-2 rounded-full border border-white/15 bg-white/5 px-4 py-1.5 text-xs font-semibold uppercase tracking-widest text-gold-300 backdrop-blur">
              <span className="h-2 w-2 animate-pulse rounded-full bg-gold-400" />
              Admissions Open · Evening Batches
            </span>
            <h1 className="animate-fade-up delay-100 mt-6 font-display text-4xl font-bold leading-[1.1] sm:text-5xl lg:text-6xl">
              Where Hard Work Meets <span className="gold-text">Academic Excellence</span>
            </h1>
            <p className="animate-fade-up delay-200 mt-6 max-w-xl text-lg leading-relaxed text-white/70">
              FAAST ACADEMY offers focused evening coaching for Classes 9 to 12 in Faisalabad, with a modern student
              portal to track marks, percentages, attendance and fee dues, anytime.
            </p>
            <div className="animate-fade-up delay-300 mt-9 flex flex-wrap gap-4">
              <Link href="/login" className="btn btn-gold">
                Open Student Portal →
              </Link>
              <a href="#enquiry" className="btn btn-ghost">
                Apply for Admission
              </a>
            </div>
            <dl className="animate-fade-up delay-400 mt-12 grid max-w-md grid-cols-3 gap-6 border-t border-white/10 pt-8">
              {[
                ["4", "Classes (9–12)"],
                ["6 days", "Per week"],
                ["24/7", "Portal access"],
              ].map(([v, l]) => (
                <div key={l}>
                  <dt className="font-display text-2xl font-bold text-gold-400">{v}</dt>
                  <dd className="mt-1 text-xs text-white/60">{l}</dd>
                </div>
              ))}
            </dl>
          </div>

          {/* Portal preview mock */}
          <div className="animate-fade-up delay-300 relative mx-auto w-full max-w-lg">
            <div className="animate-float rounded-3xl border border-white/15 bg-white/10 p-5 shadow-2xl shadow-black/40 backdrop-blur-xl">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-white/60">Welcome back</p>
                  <p className="font-display text-lg font-semibold">Fatima Noor · 10th</p>
                </div>
                <span className="rounded-full bg-emerald-400/20 px-3 py-1 text-xs font-semibold text-emerald-300">Active</span>
              </div>
              <div className="mt-5 grid grid-cols-3 gap-3">
                {[
                  ["Overall", "78%", "text-gold-300"],
                  ["Attendance", "92%", "text-emerald-300"],
                  ["Fee Due", "Rs. 0", "text-sky-300"],
                ].map(([l, v, c]) => (
                  <div key={l} className="rounded-2xl bg-navy-950/60 p-3 text-center">
                    <p className={`font-display text-xl font-bold ${c}`}>{v}</p>
                    <p className="mt-1 text-[11px] text-white/60">{l}</p>
                  </div>
                ))}
              </div>
              <div className="mt-5 space-y-3">
                {[
                  ["Physics", 82],
                  ["Chemistry", 74],
                  ["Mathematics", 88],
                  ["English", 69],
                ].map(([s, v], i) => (
                  <div key={s}>
                    <div className="mb-1 flex justify-between text-xs text-white/70">
                      <span>{s}</span>
                      <span>{v}%</span>
                    </div>
                    <div className="h-2 overflow-hidden rounded-full bg-white/10">
                      <div
                        className="h-full rounded-full bg-gradient-to-r from-gold-500 to-gold-300"
                        style={{ width: `${v}%`, animation: `fade-in 1s ease ${0.6 + i * 0.15}s both` }}
                      />
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div className="animate-float-slow absolute -bottom-6 -left-4 rounded-2xl bg-white px-4 py-3 text-navy-900 shadow-xl sm:-left-10">
              <p className="text-[11px] font-medium text-slate-500">This month</p>
              <p className="font-display text-lg font-bold">✔ Fee Paid</p>
            </div>
            <div className="animate-float absolute -right-3 -top-5 rounded-2xl bg-gold-400 px-4 py-3 text-navy-900 shadow-xl [animation-delay:-3s] sm:-right-8">
              <p className="text-[11px] font-semibold">Mid-Term</p>
              <p className="font-display text-lg font-bold">Grade A</p>
            </div>
          </div>
        </div>
      </section>

      {/* CLASSES & FEES */}
      <section id="classes" className="scroll-mt-20 bg-slate-50 py-24">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="mx-auto max-w-2xl text-center">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-600">Classes & Fee Structure</p>
            <h2 className="mt-3 font-display text-3xl font-bold text-navy-900 sm:text-4xl">Simple, transparent fees</h2>
            <p className="mt-4 text-slate-600">Evening coaching from 9th to 12th class. No hidden charges.</p>
          </Reveal>

          <div className="mt-14 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {classCards.map((c, i) => (
              <Reveal key={c.cls} delay={i * 100}>
                <div
                  className={`card-lift relative flex h-full flex-col rounded-3xl border p-7 ${
                    c.popular
                      ? "border-transparent bg-navy-900 text-white"
                      : "border-slate-200 bg-white text-slate-900"
                  }`}
                >
                  {c.popular && (
                    <span className="absolute -top-3 right-6 rounded-full bg-gold-400 px-3 py-1 text-[11px] font-bold uppercase tracking-wider text-navy-900">
                      Board Year
                    </span>
                  )}
                  <span
                    className={`grid h-12 w-12 place-items-center rounded-2xl font-display text-xl font-bold ${
                      c.popular ? "bg-gold-400 text-navy-900" : "bg-navy-50 text-navy-700"
                    }`}
                  >
                    {c.cls}
                  </span>
                  <h3 className="mt-5 font-display text-xl font-bold">{c.title}</h3>
                  <p className={`mt-2 flex-1 text-sm leading-relaxed ${c.popular ? "text-white/70" : "text-slate-600"}`}>
                    {c.desc}
                  </p>
                  <div className="mt-6 flex flex-wrap gap-1.5">
                    {c.subjects.map((s) => (
                      <span
                        key={s}
                        className={`rounded-full px-2.5 py-1 text-[11px] font-medium ${
                          c.popular ? "bg-white/10 text-white/80" : "bg-slate-100 text-slate-600"
                        }`}
                      >
                        {s}
                      </span>
                    ))}
                  </div>
                  <div className={`mt-7 border-t pt-5 ${c.popular ? "border-white/10" : "border-slate-100"}`}>
                    <p className={`text-xs ${c.popular ? "text-white/60" : "text-slate-500"}`}>Fee per month</p>
                    <p className={`font-display text-3xl font-bold ${c.popular ? "text-gold-400" : "text-navy-800"}`}>
                      {money(CLASS_FEES[c.cls])}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* PORTAL */}
      <section id="portal" className="relative scroll-mt-20 overflow-hidden bg-white py-24">
        <div className="mx-auto max-w-7xl px-5">
          <div className="grid items-center gap-14 lg:grid-cols-[1fr_1.3fr]">
            <Reveal>
              <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-600">Student Portal</p>
              <h2 className="mt-3 font-display text-3xl font-bold text-navy-900 sm:text-4xl">
                Your academic progress, always in your pocket
              </h2>
              <p className="mt-4 leading-relaxed text-slate-600">
                Every FAAST student gets a personal login. Check test marks, see how your percentage is improving, keep
                an eye on attendance and know exactly what fee is due, with no need to visit the office to ask.
              </p>
              <div className="mt-8 flex flex-wrap gap-3">
                <Link href="/login" className="btn btn-navy">
                  Student Login
                </Link>
                <a href="#enquiry" className="btn btn-outline">
                  Not a student yet?
                </a>
              </div>
            </Reveal>
            <div className="grid gap-4 sm:grid-cols-2">
              {portalFeatures.map((f, i) => (
                <Reveal key={f.title} delay={i * 80}>
                  <div className="card-lift h-full rounded-2xl border border-slate-200 bg-slate-50 p-5">
                    <span className="grid h-11 w-11 place-items-center rounded-xl bg-white text-xl shadow-sm">{f.icon}</span>
                    <h3 className="mt-4 font-semibold text-navy-900">{f.title}</h3>
                    <p className="mt-1 text-sm leading-relaxed text-slate-600">{f.text}</p>
                  </div>
                </Reveal>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* WHY */}
      <section id="why" className="scroll-mt-20 bg-navy-950 py-24 text-white">
        <div className="mx-auto max-w-7xl px-5">
          <Reveal className="max-w-2xl">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-400">Why FAAST</p>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">Built for results, run with discipline</h2>
          </Reveal>
          <div className="mt-12 grid gap-px overflow-hidden rounded-3xl bg-white/10 sm:grid-cols-2 lg:grid-cols-4">
            {why.map((w, i) => (
              <Reveal key={w.n} delay={i * 100} className="bg-navy-950">
                <div className="group h-full p-8 transition-colors duration-500 hover:bg-navy-900">
                  <p className="font-display text-4xl font-bold text-white/15 transition-colors duration-500 group-hover:text-gold-400">
                    {w.n}
                  </p>
                  <h3 className="mt-6 text-lg font-semibold">{w.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-white/60">{w.text}</p>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </section>

      {/* LOCATION */}
      <section id="location" className="scroll-mt-20 bg-slate-50 py-24">
        <div className="mx-auto grid max-w-7xl items-stretch gap-8 px-5 lg:grid-cols-2">
          <Reveal>
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-600">Visit Us</p>
            <h2 className="mt-3 font-display text-3xl font-bold text-navy-900 sm:text-4xl">Find us at Kohinoor Ali Tower</h2>
            <p className="mt-4 text-slate-600">Our academy is conveniently located in Faisalabad. Drop by for a visit and meet our teachers.</p>
            <ul className="mt-8 space-y-4">
              {[
                ["📍", "Address", "Kohinoor Ali Tower, Faisalabad, Punjab"],
                ["🕕", "Timings", "Evening batches · Monday to Saturday"],
                ["🎓", "Classes", "9th, 10th, 11th & 12th"],
              ].map(([i, t, d]) => (
                <li key={t} className="flex gap-4 rounded-2xl border border-slate-200 bg-white p-4 transition-shadow duration-300 hover:shadow-lg">
                  <span className="grid h-11 w-11 shrink-0 place-items-center rounded-xl bg-navy-50 text-xl">{i}</span>
                  <div>
                    <p className="text-sm font-semibold text-navy-900">{t}</p>
                    <p className="text-sm text-slate-600">{d}</p>
                  </div>
                </li>
              ))}
            </ul>
          </Reveal>
          <Reveal delay={150} className="min-h-[360px]">
            <div className="h-full min-h-[360px] overflow-hidden rounded-3xl border border-slate-200 shadow-xl">
              <iframe
                title="FAAST ACADEMY location"
                src="https://maps.google.com/maps?q=Kohinoor%20Ali%20Tower%20Faisalabad&t=&z=15&ie=UTF8&iwloc=&output=embed"
                className="h-full min-h-[360px] w-full"
                loading="lazy"
              />
            </div>
          </Reveal>
        </div>
      </section>

      {/* ENQUIRY */}
      <section id="enquiry" className="relative scroll-mt-20 overflow-hidden bg-gradient-to-br from-navy-900 to-navy-700 py-24">
        <div className="animate-drift absolute -right-24 -top-24 h-96 w-96 rounded-full bg-gold-500/20 blur-3xl" />
        <div className="relative mx-auto grid max-w-6xl items-center gap-12 px-5 lg:grid-cols-2">
          <Reveal className="text-white">
            <p className="text-sm font-semibold uppercase tracking-[0.2em] text-gold-400">Admissions</p>
            <h2 className="mt-3 font-display text-3xl font-bold sm:text-4xl">Join FAAST ACADEMY this session</h2>
            <p className="mt-4 leading-relaxed text-white/70">
              Send us a quick enquiry and our team will call you to share the batch schedule and admission details.
            </p>
            <ul className="mt-8 space-y-3 text-sm text-white/80">
              {["9th & 10th Class: Rs. 10,000 per month", "11th & 12th Class: Rs. 12,000 per month", "Student portal login included"].map(
                (t) => (
                  <li key={t} className="flex items-center gap-3">
                    <span className="grid h-6 w-6 place-items-center rounded-full bg-gold-400 text-xs font-bold text-navy-900">✓</span>
                    {t}
                  </li>
                ),
              )}
            </ul>
          </Reveal>
          <Reveal delay={150}>
            <div className="rounded-3xl bg-white p-7 shadow-2xl sm:p-9">
              <h3 className="font-display text-xl font-bold text-navy-900">Admission Enquiry</h3>
              <div className="mt-5">
                <EnquiryForm />
              </div>
            </div>
          </Reveal>
        </div>
      </section>

      {/* FOOTER */}
      <footer className="bg-navy-950 py-12 text-white/70">
        <div className="mx-auto flex max-w-7xl flex-col items-center justify-between gap-6 px-5 md:flex-row">
          <div>
            <Logo light />
            <p className="mt-3 max-w-xs text-sm">{ACADEMY.address}</p>
          </div>
          <div className="flex gap-6 text-sm">
            <Link href="/login" className="transition-colors hover:text-gold-400">
              Student Login
            </Link>
            <Link href="/admin" className="transition-colors hover:text-gold-400">
              Admin
            </Link>
            <a href="#enquiry" className="transition-colors hover:text-gold-400">
              Admission
            </a>
          </div>
          <p className="text-xs">© {new Date().getFullYear()} FAAST ACADEMY. All rights reserved.</p>
        </div>
      </footer>
    </main>
  );
}
