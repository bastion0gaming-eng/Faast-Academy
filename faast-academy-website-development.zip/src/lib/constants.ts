export const ACADEMY = {
  name: "FAAST ACADEMY",
  short: "FAAST",
  tagline: "Evening Coaching for Classes 9 – 12",
  address: "Kohinoor Ali Tower, Faisalabad",
};

export const CLASSES = [9, 10, 11, 12] as const;

export const CLASS_FEES: Record<number, number> = {
  9: 10000,
  10: 10000,
  11: 12000,
  12: 12000,
};

export const GROUPS = ["Science", "Pre-Medical", "Pre-Engineering"] as const;

export function groupsFor(cls: number): string[] {
  return cls <= 10 ? ["Science"] : ["Pre-Medical", "Pre-Engineering"];
}

export function subjectsFor(cls: number, grp: string): string[] {
  if (cls <= 10) return ["Physics", "Chemistry", "Biology", "Mathematics", "English", "Urdu"];
  if (grp === "Pre-Engineering") return ["Physics", "Chemistry", "Mathematics", "English", "Urdu"];
  return ["Physics", "Chemistry", "Biology", "English", "Urdu"];
}

export function ordinal(cls: number) {
  return `${cls}${cls === 9 || cls === 10 || cls === 11 || cls === 12 ? "th" : ""}`;
}

export function money(n: number) {
  return `Rs. ${n.toLocaleString("en-PK")}`;
}

export function monthLabel(m: string) {
  const [y, mo] = m.split("-").map(Number);
  return new Date(Date.UTC(y, mo - 1, 1)).toLocaleDateString("en-GB", {
    month: "long",
    year: "numeric",
    timeZone: "UTC",
  });
}

export function dateLabel(d: string) {
  const [y, m, day] = d.slice(0, 10).split("-").map(Number);
  return new Date(Date.UTC(y, m - 1, day)).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
    year: "numeric",
    timeZone: "UTC",
  });
}

export function grade(pct: number) {
  if (pct >= 80) return "A+";
  if (pct >= 70) return "A";
  if (pct >= 60) return "B";
  if (pct >= 50) return "C";
  if (pct >= 40) return "D";
  return "F";
}

export function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

export function currentMonth() {
  return new Date().toISOString().slice(0, 7);
}
