import crypto from "crypto";
import { cookies } from "next/headers";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { students } from "@/db/schema";

const secret = process.env.SESSION_SECRET ?? "faast-academy-session-secret-v1";
export const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD ?? "faast-admin";

export const STUDENT_COOKIE = "faast_student";
export const ADMIN_COOKIE = "faast_admin";

function mac(value: string) {
  return crypto.createHmac("sha256", secret).update(value).digest("base64url");
}

export function sign(value: string) {
  return `${value}.${mac(value)}`;
}

export function unsign(token?: string | null): string | null {
  if (!token) return null;
  const i = token.lastIndexOf(".");
  if (i < 0) return null;
  const value = token.slice(0, i);
  const given = Buffer.from(token.slice(i + 1));
  const expected = Buffer.from(mac(value));
  if (given.length !== expected.length) return null;
  return crypto.timingSafeEqual(given, expected) ? value : null;
}

export function hashPassword(password: string) {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, stored: string) {
  const [salt, hash] = stored.split(":");
  if (!salt || !hash) return false;
  const test = crypto.scryptSync(password, salt, 64);
  const known = Buffer.from(hash, "hex");
  return test.length === known.length && crypto.timingSafeEqual(test, known);
}

export async function getStudentSession() {
  const store = await cookies();
  const value = unsign(store.get(STUDENT_COOKIE)?.value);
  if (!value) return null;
  const id = Number(value);
  if (!Number.isInteger(id)) return null;
  const [s] = await db.select().from(students).where(eq(students.id, id)).limit(1);
  return s ?? null;
}

export async function isAdmin() {
  const store = await cookies();
  return unsign(store.get(ADMIN_COOKIE)?.value) === "admin";
}
